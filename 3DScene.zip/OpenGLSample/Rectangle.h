#ifndef RECTANGLE_H
#define RECTANGLE_H

class Rectangle {
public:
	Rectangle(double width,double height);
	Rectangle();
	void setWidth(double width);
	void setHeight(double height);
	void Area();
private:
	double width,height;
};

#endif